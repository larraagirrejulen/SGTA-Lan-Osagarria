
package ru.ispras.sedna.driver;

class Debug {
    public static final boolean DEBUG = false;
}
